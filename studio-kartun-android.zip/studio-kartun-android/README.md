# Studio Kartun - Aplikasi Android (offline, tanpa PWA)

Aplikasi Android asli (APK). Seluruh aplikasi ada di dalam APK (`app/src/main/assets/www/index.html`).

- **Tanpa internet**: manifest tidak meminta izin apa pun (tidak ada `INTERNET`). Tidak ada service worker, tidak ada server.
- **Tanpa PWA**: tidak perlu Netlify/hosting, tidak perlu PWABuilder.
- **Simpan berkas** (MP4, HTML, cadangan proyek) langsung ke `Download/StudioKartun/` lewat MediaStore, tanpa izin penyimpanan.
- Layar tetap menyala saat ekspor MP4.
- Minimal Android 10 (API 29). Proyek tersimpan di penyimpanan aplikasi (hilang jika aplikasi dihapus; gunakan tombol cadangan).

## Cara membangun APK (tanpa Android Studio)

1. Buat repositori baru di GitHub, lalu unggah **isi** folder ini (atau jalankan `kirim-ke-github.sh` / `.bat`).
2. Buka tab **Actions** > **Bangun APK Android** > **Run workflow**.
3. Setelah hijau (sekitar 3-6 menit), buka run-nya, unduh artefak **StudioKartun-APK**, ekstrak, kirim `StudioKartun-debug.apk` ke HP, lalu pasang (izinkan "pasang dari sumber tidak dikenal").

## Cara dengan Android Studio

Buka folder ini (File > Open), tunggu sinkron Gradle, lalu Build > Build APK(s). Jika diminta, gunakan Gradle 8.9 dan JDK 17.

## APK rilis bertanda tangan (opsional)

1. Jalankan `./buat-keystore.sh` (perlu JDK). Simpan `rilis.jks` dan sandinya.
2. Tambahkan secret di GitHub: `KEYSTORE_BASE64` (`base64 -w0 rilis.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Jalankan workflow lagi; hasilnya ada `StudioKartun-rilis.apk`. Memberi tag `v1.0` juga melampirkannya ke Release.

APK debug cukup untuk dipakai pribadi. Jangan unggah keystore ke repositori (sudah di `.gitignore`).

## Keamanan singkat

- Tanpa izin internet; navigasi ke situs luar diblokir; WebView tanpa akses berkas/konten; debugging mati; `allowBackup=false`.
- Halaman aplikasi dimuat dari `https://appassets.androidplatform.net/` (alamat virtual lokal, bukan internet).
- CSP membatasi semua sumber ke dalam aplikasi sendiri.

## Memperbarui aplikasi

Ganti `app/src/main/assets/www/index.html` dengan versi baru, commit, jalankan workflow. Nomor versi naik otomatis.

## Catatan jujur

Proyek ini belum dikompilasi dan diuji di perangkat nyata oleh pembuatnya. Jika workflow gagal, salin log galatnya dan kirimkan untuk diperbaiki.
