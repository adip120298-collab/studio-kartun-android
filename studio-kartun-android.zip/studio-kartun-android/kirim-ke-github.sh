#!/bin/sh
# Kirim Studio Kartun ke GitHub (Linux, macOS, Termux)
cd "$(dirname "$0")" || exit 1
command -v git >/dev/null 2>&1 || { echo "Git belum terpasang."; exit 1; }
echo "Buat dulu repositori KOSONG di github.com, lalu tempel alamatnya."
printf "Alamat repositori [https://github.com/USERNAME/NAMA-REPO.git]: "
read URL
[ -n "$URL" ] || exit 1
[ -d .git ] || git init -b main
git add .
git commit -m "Studio Kartun PWA"
git remote remove origin >/dev/null 2>&1
git remote add origin "$URL"
git branch -M main
git push -u origin main || { echo "Push gagal. Periksa alamat dan login GitHub."; exit 1; }
echo
echo "Berhasil. Langkah terakhir di github.com:"
echo "Settings > Pages > Source: GitHub Actions"
