#!/usr/bin/env bash
# Membuat kunci tanda tangan untuk APK rilis. SIMPAN berkas .jks dan sandinya baik-baik;
# tanpa itu Anda tidak bisa memperbarui aplikasi yang sudah terpasang.
set -e
keytool -genkeypair -v -keystore rilis.jks -alias kartun -keyalg RSA -keysize 4096 -validity 10000
echo
echo "Isi secret GitHub berikut (Settings > Secrets and variables > Actions):"
echo "  KEYSTORE_BASE64   = $(base64 -w0 rilis.jks 2>/dev/null | head -c 20)... (jalankan: base64 -w0 rilis.jks)"
echo "  KEYSTORE_PASSWORD = sandi keystore"
echo "  KEY_ALIAS         = kartun"
echo "  KEY_PASSWORD      = sandi kunci"
