@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Kirim Studio Kartun ke GitHub ===
where git >nul 2>&1
if errorlevel 1 (
  echo Git belum terpasang. Unduh di https://git-scm.com lalu jalankan ulang.
  pause
  exit /b 1
)
echo Buat dulu repositori KOSONG di github.com, lalu tempel alamatnya.
set /p URL=Alamat repositori [https://github.com/USERNAME/NAMA-REPO.git]: 
if "%URL%"=="" exit /b 1
if not exist .git git init -b main
git add .
git commit -m "Studio Kartun PWA"
git remote remove origin >nul 2>&1
git remote add origin %URL%
git branch -M main
git push -u origin main
if errorlevel 1 (
  echo Push gagal. Periksa alamat dan login GitHub, lalu coba lagi.
  pause
  exit /b 1
)
echo.
echo Berhasil. Langkah terakhir di github.com:
echo Settings ^> Pages ^> Source: GitHub Actions
pause
